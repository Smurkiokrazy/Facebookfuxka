# Facebook Checker
[![Stage](https://img.shields.io/badge/Release-Stable-brightgreen.svg)]()
[![Build](https://img.shields.io/badge/Supported_OS-Linux-orange.svg)]()
[![Build](https://img.shields.io/badge/Supported_OS-Windows-blue.svg)]()
![](https://i.ibb.co/kH01LnW/fbcek.png)

# [ Installation ]
```
$ apt install php php-curl
$ git clone https://github.com/f0xbase/Facebook-Checker.git
$ chmod 777 -R Facebook-Checker/ && cd Facebook-Checker/
```
# [ Running ]
```
$ php fbchecker.php list.txt
```
# [ Note ]
* Simpan List Empas kalian di file .txt 
* Format Empas Email|Password
